
/*  Z80 Machine Emulation Module for Python.
    https://github.com/kosarev/z80

    Copyright (C) 2019-2026 Ivan Kosarev.
    mail@ivankosarev.com

    Published under the MIT license.
*/

#include <Python.h>

#include <algorithm>
#include <cstring>
#include <new>

#include "../z80.h"

namespace {

using z80::fast_u8;
using z80::fast_u16;
using z80::fast_u32;
using z80::least_u8;
using z80::least_u16;
using z80::least_u32;

using z80::unused;
using z80::get_low8;
using z80::get_high8;
using z80::make16;
using z80::iregp;

static inline void split16(least_u8 &h, least_u8 &l, fast_u16 n) {
    h = get_high8(n);
    l = get_low8(n);
}

class decref_guard {
public:
    decref_guard(PyObject *object)
        : object(object)
    {}

    ~decref_guard() {
        if(object)
            Py_XDECREF(object);
    }

    explicit operator bool () const {
        return object != nullptr;
    }

    PyObject *get() const {
        return object;
    }

private:
    PyObject *object;
};

template<typename B, typename S>
class machine : public B {
public:
    typedef B base;
    typedef S machine_state;

    // The events this module's logic raises.
    class events_mask : public base::events_mask {
    public:
        using typename base::events_mask::type;

        static const type ticks_limit_hit =
            type(1) << (base::events_mask::unused_bit + 0);
        static const type end_of_frame =
            type(1) << (base::events_mask::unused_bit + 1);
        static const type stop_requested =
            type(1) << (base::events_mask::unused_bit + 2);

        static const unsigned unused_bit = base::events_mask::unused_bit + 3;
    };

    static const unsigned ticks_per_frame = 100 * 1000;

    static const fast_u8 breakpoint_mark = 1u << 0;
    static const fast_u8 read_mark = 1u << 1;
    static const fast_u8 write_mark = 1u << 2;

    machine() {}

    machine_state &get_state() {
        return state;
    }

    bool is_marked_addr(fast_u16 addr, fast_u8 marks) const {
        return (address_marks[z80::mask16(addr)] & marks) != 0;
    }

    void mark_addrs(fast_u16 addr, fast_u16 size, fast_u8 marks) {
        for(fast_u16 i = 0; i != size; ++i)
            address_marks[z80::mask16(addr + i)] |=
                static_cast<least_u8>(marks);
    }

    void unmark_addrs(fast_u16 addr, fast_u16 size, fast_u8 marks) {
        for(fast_u16 i = 0; i != size; ++i)
            address_marks[z80::mask16(addr + i)] &=
                static_cast<least_u8>(~marks);
    }

    bool on_is_breakpoint_addr(fast_u16 addr) const {
        return is_marked_addr(addr, breakpoint_mark);
    }

    typename events_mask::type on_get_events() const { return events; }
    void on_set_events(typename events_mask::type new_events) {
        events = new_events;
    }

    typename events_mask::type on_run() {
        while(self().on_step() == 0) {}
        return self().on_get_events();
    }

    fast_u8 on_read(fast_u16 addr) {
        const fast_u8 default_value = 0xff;
        assert(addr < z80::address_space_size);

        // The callback observes only read-marked addresses;
        // everything else takes the native path.
        if(!on_read_callback || !is_marked_addr(addr, read_mark)) {
            return state.memory[addr];
        }

        // Never call back into Python with an exception pending;
        // produce the default value instead.
        if(PyErr_Occurred())
            return default_value;

        PyObject *arg = Py_BuildValue("(i)", addr);
        decref_guard arg_guard(arg);

        PyObject *result = PyObject_CallObject(on_read_callback, arg);
        decref_guard result_guard(result);

        // On errors, stop the run so the pending exception can
        // propagate on its end.
        if(!result) {
            self().on_raise_events(events_mask::stop_requested);
            return default_value;
        }

        if(!PyLong_Check(result)) {
            PyErr_SetString(PyExc_TypeError, "returning value must be integer");
            self().on_raise_events(events_mask::stop_requested);
            return default_value;
        }

        return z80::mask8(PyLong_AsUnsignedLong(result));
    }

    PyObject *set_read_callback(PyObject *callback) {
        PyObject *old_callback = on_read_callback;
        on_read_callback = callback;
        return old_callback;
    }

    void on_write(fast_u16 addr, fast_u8 n) {
        assert(addr < z80::address_space_size);

        // The callback replaces storage for write-marked
        // addresses; everything else takes the native path.
        if(!on_write_callback || !is_marked_addr(addr, write_mark)) {
            state.memory[addr] = n;
            return;
        }

        if(PyErr_Occurred())
            return;

        PyObject *args = Py_BuildValue("(i, i)", addr, n);
        decref_guard arg_guard(args);

        PyObject *result = PyObject_CallObject(on_write_callback, args);
        decref_guard result_guard(result);

        if(!result)
            self().on_raise_events(events_mask::stop_requested);
    }

    PyObject *set_write_callback(PyObject *callback) {
        PyObject *old_callback = on_write_callback;
        on_write_callback = callback;
        return old_callback;
    }

    fast_u8 on_input(fast_u16 addr) {
        const fast_u8 default_value = 0xff;
        if(!on_input_callback)
            return default_value;

        if(PyErr_Occurred())
            return default_value;

        PyObject *arg = Py_BuildValue("(i)", addr);
        decref_guard arg_guard(arg);

        PyObject *result = PyObject_CallObject(on_input_callback, arg);
        decref_guard result_guard(result);

        if(!result) {
            self().on_raise_events(events_mask::stop_requested);
            return default_value;
        }

        if(!PyLong_Check(result)) {
            PyErr_SetString(PyExc_TypeError, "returning value must be integer");
            self().on_raise_events(events_mask::stop_requested);
            return default_value;
        }

        return z80::mask8(PyLong_AsUnsignedLong(result));
    }

    PyObject *set_input_callback(PyObject *callback) {
        PyObject *old_callback = on_input_callback;
        on_input_callback = callback;
        return old_callback;
    }

    void on_output(fast_u16 addr, fast_u8 value) {
        if(!on_output_callback)
            return;

        if(PyErr_Occurred())
            return;

        PyObject *args = Py_BuildValue("(i, i)", addr, value);
        decref_guard arg_guard(args);

        PyObject *result = PyObject_CallObject(on_output_callback, args);
        decref_guard result_guard(result);

        if(!result)
            self().on_raise_events(events_mask::stop_requested);
    }

    PyObject *set_output_callback(PyObject *callback) {
        PyObject *old_callback = on_output_callback;
        on_output_callback = callback;
        return old_callback;
    }

    void on_reti() {
        base::on_reti();

        if(on_reti_callback && !PyErr_Occurred()) {
            PyObject *result = PyObject_CallObject(on_reti_callback, NULL);
            decref_guard result_guard(result);

            if(!result)
                self().on_raise_events(events_mask::stop_requested);
        }
    }

    PyObject *set_reti_callback(PyObject *callback) {
        PyObject *old_callback = on_reti_callback;
        on_reti_callback = callback;
        return old_callback;
    }

    fast_u8 on_get_int_vector() {
        const fast_u8 default_value = 0xff;
        if(!on_get_int_vector_callback)
            return base::on_get_int_vector();

        if(PyErr_Occurred())
            return default_value;

        PyObject *result = PyObject_CallObject(on_get_int_vector_callback, NULL);
        decref_guard result_guard(result);

        if(!result) {
            self().on_raise_events(events_mask::stop_requested);
            return default_value;
        }

        if(!PyLong_Check(result)) {
            PyErr_SetString(PyExc_TypeError, "returning value must be integer");
            self().on_raise_events(events_mask::stop_requested);
            return default_value;
        }

        return z80::mask8(PyLong_AsUnsignedLong(result));
    }

    PyObject *set_get_int_vector_callback(PyObject *callback) {
        PyObject *old_callback = on_get_int_vector_callback;
        on_get_int_vector_callback = callback;
        return old_callback;
    }

    fast_u8 on_get_b() const { return state.b; }
    void on_set_b(fast_u8 n) { state.b = n; }

    fast_u8 on_get_c() const { return state.c; }
    void on_set_c(fast_u8 n) { state.c = n; }

    fast_u8 on_get_d() const { return state.d; }
    void on_set_d(fast_u8 n) { state.d = n; }

    fast_u8 on_get_e() const { return state.e; }
    void on_set_e(fast_u8 n) { state.e = n; }

    fast_u8 on_get_h() const { return state.h; }
    void on_set_h(fast_u8 n) { state.h = n; }

    fast_u8 on_get_l() const { return state.l; }
    void on_set_l(fast_u8 n) { state.l = n; }

    fast_u8 on_get_a() const { return state.a; }
    void on_set_a(fast_u8 n) { state.a = n; }

    fast_u8 on_get_f() const { return state.f; }
    void on_set_f(fast_u8 n) { state.f = n; }

    fast_u16 on_get_bc() const { return make16(state.b, state.c); }
    void on_set_bc(fast_u16 n) { split16(state.b, state.c, n); }

    fast_u16 on_get_de() const { return make16(state.d, state.e); }
    void on_set_de(fast_u16 n) { split16(state.d, state.e, n); }

    fast_u16 on_get_hl() const { return make16(state.h, state.l); }
    void on_set_hl(fast_u16 n) { split16(state.h, state.l, n); }

    fast_u16 on_get_af() const { return make16(state.a, state.f); }
    void on_set_af(fast_u16 n) { split16(state.a, state.f, n); }

    fast_u16 on_get_pc() const { return state.pc; }
    void on_set_pc(fast_u16 n) { state.pc = n; }

    fast_u16 on_get_sp() const { return state.sp; }
    void on_set_sp(fast_u16 n) { state.sp = n; }

    fast_u16 on_get_wz() const { return state.wz; }
    void on_set_wz(fast_u16 n) { state.wz = n; }

    fast_u16 on_get_last_read_addr() const { return state.last_read_addr; }
    void on_set_last_read_addr(fast_u16 n) { state.last_read_addr = n; }

    bool on_is_int_disabled() const { return state.int_disabled; }
    void on_set_is_int_disabled(bool f) { state.int_disabled = f; }

    bool on_is_halted() const { return state.halted; }
    void on_set_is_halted(bool f) { state.halted = f; }

    void on_ex_de_hl_regs() {
        std::swap(state.d, state.h);
        std::swap(state.e, state.l);
    }

    void on_tick(unsigned t) {
        base::on_tick(t);

        // Handle stopping by hitting a specified number of ticks.
        if(state.ticks_to_stop) {
            if(state.ticks_to_stop > t) {
                state.ticks_to_stop -= t;
            } else {
                state.ticks_to_stop = 0;
                self().on_raise_events(events_mask::ticks_limit_hit);
            }
        }

        // Account the ticks toward the current frame.
        state.frame_tick += t;
        if(state.frame_tick >= ticks_per_frame) {
            state.frame_tick %= ticks_per_frame;
            self().on_raise_events(events_mask::end_of_frame);
        }
    }

#if 0  // TODO
    events_mask::type on_step() {
        fprintf(stderr, "PC=%04x SP=%04x BC=%04x DE=%04x HL=%04x AF=%04x %02x%02x%02x%02x\n",
                static_cast<unsigned>(state.pc),
                static_cast<unsigned>(state.sp),
                static_cast<unsigned>(make16(state.b, state.c)),
                static_cast<unsigned>(make16(state.d, state.e)),
                static_cast<unsigned>(make16(state.h, state.l)),
                static_cast<unsigned>(make16(state.a, state.f)),
                static_cast<unsigned>(state.memory[(state.pc + 0) & 0xffff]),
                static_cast<unsigned>(state.memory[(state.pc + 1) & 0xffff]),
                static_cast<unsigned>(state.memory[(state.pc + 2) & 0xffff]),
                static_cast<unsigned>(state.memory[(state.pc + 3) & 0xffff]));
        return base::on_step();
    }
#endif

protected:
    using base::self;
    machine_state state;

private:
    typename events_mask::type events = 0;
    least_u8 address_marks[z80::address_space_size] = {};

    PyObject *on_read_callback = nullptr;
    PyObject *on_write_callback = nullptr;
    PyObject *on_input_callback = nullptr;
    PyObject *on_output_callback = nullptr;
    PyObject *on_reti_callback = nullptr;
    PyObject *on_get_int_vector_callback = nullptr;
};

static const unsigned max_instr_size = 4;

static constexpr inline unsigned get_char_code(char c) {
    return static_cast<unsigned char>(c);
}

template<typename B>
class disasm_base : public B {
public:
    typedef B base;

    disasm_base() {}

    const char *get_output() const {
        return output_buff;
    }

    void on_emit(const char *out) {
        std::snprintf(output_buff, max_output_buff_size, "%s", out);
    }

    void on_format_char(char c, const void **&args,
                        typename base::output_buff &out) {
        unsigned n = get_char_code(c);
        if(get_char_code('A') <= n && n <= get_char_code('Z'))
            out.append(c);
        base::on_format_char(c, args, out);
    }

    fast_u8 on_read_next_byte() {
        assert(index < instr_size);
        return instr_code[index++];
    }

    void set_instr_code(const least_u8 *code, unsigned size) {
        assert(size <= max_instr_size);
        std::memset(instr_code, 0, max_instr_size);
        std::memcpy(instr_code, code, size);
        index = 0;
        output_buff[0] = '\0';
    }

    unsigned get_num_of_consumed_bytes() const {
        return index;
    }

private:
    unsigned index = 0;
    least_u8 instr_code[max_instr_size];

    static const std::size_t max_output_buff_size = 32;
    char output_buff[max_output_buff_size];
};

namespace i8080_machine {
#define I8080_MACHINE
#include "machine.inc"
#undef I8080_MACHINE
}

namespace z80_machine {
#define Z80_MACHINE
#include "machine.inc"
#undef Z80_MACHINE
}

static PyModuleDef module = {
    PyModuleDef_HEAD_INIT,      // m_base
    "z80._z80",                 // m_name
    "Z80 Machine Emulation Module",
                                // m_doc
    -1,                         // m_size
    nullptr,                    // m_methods
    nullptr,                    // m_slots
    nullptr,                    // m_traverse
    nullptr,                    // m_clear
    nullptr,                    // m_free
};

}  // anonymous namespace

extern "C" PyMODINIT_FUNC PyInit__z80(void) {
    PyObject *m = PyModule_Create(&module);
    if(!m)
        return nullptr;

    if(PyType_Ready(&z80_machine::type_object) < 0)
        return nullptr;
    if(PyType_Ready(&i8080_machine::type_object) < 0)
        return nullptr;
    Py_INCREF(&z80_machine::type_object);
    Py_INCREF(&i8080_machine::type_object);

    // TODO: Check the returning value.
    PyModule_AddObject(m, "_Z80Machine",
                       &z80_machine::type_object.ob_base.ob_base);
    PyModule_AddObject(m, "_I8080Machine",
                       &i8080_machine::type_object.ob_base.ob_base);
    return m;
}
