#   Z80 CPU Emulator.
#   https://github.com/kosarev/z80
#
#   Copyright (C) 2026 Ivan Kosarev.
#   mail@ivankosarev.com
#
#   Published under the MIT license.

import pytest

import z80


# The sanctioned creation path for symbols is their context's
# get_symbol(); a fresh context per symbol serves these tests.
def _symbol(name: str, value: int | None = None) -> z80.Symbol:
    symbol = z80.Code().get_symbol(name)
    if value is not None:
        symbol.define(value)

    return symbol


# The operand-free instructions and their fixed encodings.
_TESTS = (
    (z80.NOP(), b'\x00'),
    (z80.RLCA(), b'\x07'),
    (z80.RRCA(), b'\x0f'),
    (z80.RLA(), b'\x17'),
    (z80.RRA(), b'\x1f'),
    (z80.DAA(), b'\x27'),
    (z80.CPL(), b'\x2f'),
    (z80.SCF(), b'\x37'),
    (z80.CCF(), b'\x3f'),
    (z80.HALT(), b'\x76'),
    (z80.EXX(), b'\xd9'),
    (z80.DI(), b'\xf3'),
    (z80.EI(), b'\xfb'),
    (z80.NEG(), b'\xed\x44'),
    (z80.RETN(), b'\xed\x45'),
    (z80.RETI(), b'\xed\x4d'),
    (z80.RRD(), b'\xed\x67'),
    (z80.RLD(), b'\xed\x6f'),
    (z80.LDI(), b'\xed\xa0'),
    (z80.CPI(), b'\xed\xa1'),
    (z80.INI(), b'\xed\xa2'),
    (z80.OUTI(), b'\xed\xa3'),
    (z80.LDD(), b'\xed\xa8'),
    (z80.CPD(), b'\xed\xa9'),
    (z80.IND(), b'\xed\xaa'),
    (z80.OUTD(), b'\xed\xab'),
    (z80.LDIR(), b'\xed\xb0'),
    (z80.CPIR(), b'\xed\xb1'),
    (z80.INIR(), b'\xed\xb2'),
    (z80.OTIR(), b'\xed\xb3'),
    (z80.LDDR(), b'\xed\xb8'),
    (z80.CPDR(), b'\xed\xb9'),
    (z80.INDR(), b'\xed\xba'),
    (z80.OTDR(), b'\xed\xbb'),
    (z80.RST(0x00), b'\xc7'),
    (z80.RST(0x08), b'\xcf'),
    (z80.RST(0x10), b'\xd7'),
    (z80.RST(0x18), b'\xdf'),
    (z80.RST(0x20), b'\xe7'),
    (z80.RST(0x28), b'\xef'),
    (z80.RST(0x30), b'\xf7'),
    (z80.RST(0x38), b'\xff'),
    (z80.RST(_symbol('main', 0x28)), b'\xef'),
    (z80.IM(0), b'\xed\x46'),
    (z80.IM(1), b'\xed\x56'),
    (z80.IM(2), b'\xed\x5e'),
    (z80.XPREFIX(0xdd), b'\xdd'),
    (z80.XPREFIX(0xfd), b'\xfd'),
    (z80.EX(z80.AF, z80.AF2), b'\x08'),
    (z80.EX(z80.DE, z80.HL), b'\xeb'),
    (z80.EX(z80.At(z80.SP), z80.HL), b'\xe3'),
    (z80.EX(z80.At(z80.SP), z80.IX), b'\xdd\xe3'),
    (z80.EX(z80.At(z80.SP), z80.IY), b'\xfd\xe3'),
    (z80.JP(z80.At(z80.HL)), b'\xe9'),
    (z80.JP(z80.At(z80.IX)), b'\xdd\xe9'),
    (z80.JP(z80.At(z80.IY)), b'\xfd\xe9'),
    (z80.JP(z80.At(z80.IX, 0)), b'\xdd\xe9'),
    (z80.JP(0x1234), b'\xc3\x34\x12'),
    (z80.JP(_symbol('main', 0x8000)), b'\xc3\x00\x80'),
    (z80.JP(z80.NZ, 0x1234), b'\xc2\x34\x12'),
    (z80.JP(z80.CF, 0x1234), b'\xda\x34\x12'),
    (z80.JP(z80.M, 0x1234), b'\xfa\x34\x12'),
    (z80.CALL(0x1234), b'\xcd\x34\x12'),
    (z80.CALL(z80.NZ, 0x1234), b'\xc4\x34\x12'),
    (z80.CALL(z80.CF, 0x1234), b'\xdc\x34\x12'),
    (z80.CALL(z80.M, 0x1234), b'\xfc\x34\x12'),
    (z80.RET(), b'\xc9'),
    (z80.RET(z80.NZ), b'\xc0'),
    (z80.RET(z80.Z), b'\xc8'),
    (z80.RET(z80.NC), b'\xd0'),
    (z80.RET(z80.CF), b'\xd8'),
    (z80.RET(z80.PO), b'\xe0'),
    (z80.RET(z80.PE), b'\xe8'),
    (z80.RET(z80.P), b'\xf0'),
    (z80.RET(z80.M), b'\xf8'),
    (z80.IN(z80.At(z80.C)), b'\xed\x70'),
    (z80.IN(z80.B, z80.At(z80.C)), b'\xed\x40'),
    (z80.IN(z80.C, z80.At(z80.C)), b'\xed\x48'),
    (z80.IN(z80.A, z80.At(z80.C)), b'\xed\x78'),
    (z80.OUT(z80.At(z80.C), 0), b'\xed\x71'),
    (z80.OUT(z80.At(z80.C), z80.B), b'\xed\x41'),
    (z80.OUT(z80.At(z80.C), z80.A), b'\xed\x79'),
    (z80.LD(z80.A, z80.At(z80.BC)), b'\x0a'),
    (z80.LD(z80.A, z80.At(z80.DE)), b'\x1a'),
    (z80.LD(z80.At(z80.BC), z80.A), b'\x02'),
    (z80.LD(z80.At(z80.DE), z80.A), b'\x12'),
    (z80.LD(z80.SP, z80.HL), b'\xf9'),
    (z80.LD(z80.SP, z80.IX), b'\xdd\xf9'),
    (z80.LD(z80.SP, z80.IY), b'\xfd\xf9'),
    (z80.LD(z80.IReg, z80.A), b'\xed\x47'),
    (z80.LD(z80.R, z80.A), b'\xed\x4f'),
    (z80.LD(z80.A, z80.IReg), b'\xed\x57'),
    (z80.LD(z80.A, z80.R), b'\xed\x5f'),
    (z80.LD(z80.B, z80.C), b'\x41'),
    (z80.LD(z80.A, z80.B), b'\x78'),
    (z80.LD(z80.H, z80.L), b'\x65'),
    (z80.LD(z80.B, z80.At(z80.HL)), b'\x46'),
    (z80.LD(z80.At(z80.HL), z80.B), b'\x70'),
    (z80.LD(z80.H, z80.At(z80.HL)), b'\x66'),
    (z80.LD(z80.IXH, z80.B), b'\xdd\x60'),
    (z80.LD(z80.B, z80.IYL), b'\xfd\x45'),
    (z80.LD(z80.IXH, z80.IXL), b'\xdd\x65'),
    (z80.LD(z80.B, 0x55), b'\x06\x55'),
    (z80.LD(z80.A, -1), b'\x3e\xff'),
    (z80.LD(z80.IXH, 0x55), b'\xdd\x26\x55'),
    (z80.LD(z80.IYL, 0x55), b'\xfd\x2e\x55'),
    (z80.LD(z80.At(z80.HL), 0x55), b'\x36\x55'),
    (z80.LD(z80.BC, 0x1234), b'\x01\x34\x12'),
    (z80.LD(z80.DE, 0x1234), b'\x11\x34\x12'),
    (z80.LD(z80.HL, 0x1234), b'\x21\x34\x12'),
    (z80.LD(z80.SP, 0x1234), b'\x31\x34\x12'),
    (z80.LD(z80.IX, 0x1234), b'\xdd\x21\x34\x12'),
    (z80.LD(z80.IY, 0x1234), b'\xfd\x21\x34\x12'),
    (z80.LD(z80.A, z80.At(0x1234)), b'\x3a\x34\x12'),
    (z80.LD(z80.At(0x1234), z80.A), b'\x32\x34\x12'),
    (z80.LD(z80.HL, z80.At(0x1234)), b'\x2a\x34\x12'),
    (z80.LD(z80.At(0x1234), z80.HL), b'\x22\x34\x12'),
    (z80.LD(z80.IX, z80.At(0x1234)), b'\xdd\x2a\x34\x12'),
    (z80.LD(z80.At(0x1234), z80.IY), b'\xfd\x22\x34\x12'),
    (z80.LD(z80.BC, z80.At(0x1234)), b'\xed\x4b\x34\x12'),
    (z80.LD(z80.At(0x1234), z80.BC), b'\xed\x43\x34\x12'),
    (z80.LD(z80.DE, z80.At(0x1234)), b'\xed\x5b\x34\x12'),
    (z80.LD(z80.At(0x1234), z80.DE), b'\xed\x53\x34\x12'),
    (z80.LD(z80.SP, z80.At(0x1234)), b'\xed\x7b\x34\x12'),
    (z80.LD(z80.At(0x1234), z80.SP), b'\xed\x73\x34\x12'),
    (z80.INC(z80.At(z80.IX, 5)), b'\xdd\x34\x05'),
    (z80.INC(z80.At(z80.IX)), b'\xdd\x34\x00'),
    (z80.DEC(z80.At(z80.IY, -1)), b'\xfd\x35\xff'),
    (z80.ADD(z80.A, z80.At(z80.IX, 5)), b'\xdd\x86\x05'),
    (z80.SUB(z80.At(z80.IY, 0)), b'\xfd\x96\x00'),
    (z80.CP(z80.At(z80.IX, -2)), b'\xdd\xbe\xfe'),
    (z80.LD(z80.B, z80.At(z80.IX, 5)), b'\xdd\x46\x05'),
    (z80.LD(z80.H, z80.At(z80.IX, 5)), b'\xdd\x66\x05'),
    (z80.LD(z80.At(z80.IY, 5), z80.C), b'\xfd\x71\x05'),
    (z80.LD(z80.At(z80.IX, 5), 0x55), b'\xdd\x36\x05\x55'),
    (z80.RLC(z80.At(z80.IX, 5)), b'\xdd\xcb\x05\x06'),
    (z80.SRL(z80.At(z80.IY, -1)), b'\xfd\xcb\xff\x3e'),
    (z80.RLC(z80.At(z80.IX, 5), z80.B), b'\xdd\xcb\x05\x00'),
    (z80.RES(z80.C, 2, z80.At(z80.IY, 5)), b'\xfd\xcb\x05\x91'),
    (z80.SET(z80.C, 0, z80.At(z80.IX, 5)), b'\xdd\xcb\x05\xc1'),
    (z80.BIT(z80.A, 0, z80.At(z80.IX, 5)), b'\xdd\xcb\x05\x47'),
    (z80.BIT(3, z80.At(z80.IX, 5)), b'\xdd\xcb\x05\x5e'),
    (z80.XLD(0xed63, z80.At(0x1234), z80.HL), b'\xed\x63\x34\x12'),
    (z80.XLD(0xed6b, z80.HL, z80.At(0x1234)), b'\xed\x6b\x34\x12'),
    (z80.IN(z80.A, z80.At(0x12)), b'\xdb\x12'),
    (z80.OUT(z80.At(0x12), z80.A), b'\xd3\x12'),
    (z80.XNEG(0xed4c), b'\xed\x4c'),
    (z80.XNEG(0xed54), b'\xed\x54'),
    (z80.XNEG(0xed7c), b'\xed\x7c'),
    (z80.XRETN(0xed55), b'\xed\x55'),
    (z80.XRETN(0xed5d), b'\xed\x5d'),
    (z80.XRETN(0xed7d), b'\xed\x7d'),
    (z80.XIM(0xed4e, 0), b'\xed\x4e'),
    (z80.XIM(0xed66, 0), b'\xed\x66'),
    (z80.XIM(0xed6e, 0), b'\xed\x6e'),
    (z80.XIM(0xed76, 1), b'\xed\x76'),
    (z80.XIM(0xed7e, 2), b'\xed\x7e'),
    (z80.PUSH(z80.BC), b'\xc5'),
    (z80.PUSH(z80.DE), b'\xd5'),
    (z80.PUSH(z80.HL), b'\xe5'),
    (z80.PUSH(z80.AF), b'\xf5'),
    (z80.PUSH(z80.IX), b'\xdd\xe5'),
    (z80.PUSH(z80.IY), b'\xfd\xe5'),
    (z80.POP(z80.BC), b'\xc1'),
    (z80.POP(z80.DE), b'\xd1'),
    (z80.POP(z80.HL), b'\xe1'),
    (z80.POP(z80.AF), b'\xf1'),
    (z80.POP(z80.IX), b'\xdd\xe1'),
    (z80.POP(z80.IY), b'\xfd\xe1'),
    (z80.INC(z80.B), b'\x04'),
    (z80.INC(z80.A), b'\x3c'),
    (z80.INC(z80.At(z80.HL)), b'\x34'),
    (z80.INC(z80.IXH), b'\xdd\x24'),
    (z80.INC(z80.IYL), b'\xfd\x2c'),
    (z80.INC(z80.BC), b'\x03'),
    (z80.INC(z80.SP), b'\x33'),
    (z80.INC(z80.IX), b'\xdd\x23'),
    (z80.INC(z80.IY), b'\xfd\x23'),
    (z80.DEC(z80.B), b'\x05'),
    (z80.DEC(z80.A), b'\x3d'),
    (z80.DEC(z80.At(z80.HL)), b'\x35'),
    (z80.DEC(z80.IXH), b'\xdd\x25'),
    (z80.DEC(z80.IYL), b'\xfd\x2d'),
    (z80.DEC(z80.BC), b'\x0b'),
    (z80.DEC(z80.SP), b'\x3b'),
    (z80.DEC(z80.IX), b'\xdd\x2b'),
    (z80.DEC(z80.IY), b'\xfd\x2b'),
    (z80.SUB(z80.B), b'\x90'),
    (z80.SUB(z80.A), b'\x97'),
    (z80.SUB(z80.At(z80.HL)), b'\x96'),
    (z80.SUB(z80.IXH), b'\xdd\x94'),
    (z80.SUB(z80.IYL), b'\xfd\x95'),
    (z80.AND(z80.B), b'\xa0'),
    (z80.AND(z80.At(z80.HL)), b'\xa6'),
    (z80.XOR(z80.B), b'\xa8'),
    (z80.XOR(z80.IXH), b'\xdd\xac'),
    (z80.OR(z80.B), b'\xb0'),
    (z80.OR(z80.A), b'\xb7'),
    (z80.CP(z80.B), b'\xb8'),
    (z80.CP(z80.At(z80.HL)), b'\xbe'),
    (z80.ADD(z80.A, z80.B), b'\x80'),
    (z80.ADD(z80.A, z80.At(z80.HL)), b'\x86'),
    (z80.ADD(z80.A, z80.IXH), b'\xdd\x84'),
    (z80.ADD(z80.HL, z80.DE), b'\x19'),
    (z80.ADD(z80.HL, z80.HL), b'\x29'),
    (z80.ADD(z80.IX, z80.BC), b'\xdd\x09'),
    (z80.ADD(z80.IX, z80.IX), b'\xdd\x29'),
    (z80.ADD(z80.IY, z80.SP), b'\xfd\x39'),
    (z80.ADC(z80.A, z80.B), b'\x88'),
    (z80.ADC(z80.HL, z80.BC), b'\xed\x4a'),
    (z80.ADC(z80.HL, z80.HL), b'\xed\x6a'),
    (z80.SBC(z80.A, z80.B), b'\x98'),
    (z80.SBC(z80.HL, z80.DE), b'\xed\x52'),
    (z80.ADD(z80.A, 0x55), b'\xc6\x55'),
    (z80.ADC(z80.A, 0x55), b'\xce\x55'),
    (z80.SUB(0x55), b'\xd6\x55'),
    (z80.SBC(z80.A, 0x55), b'\xde\x55'),
    (z80.AND(0x55), b'\xe6\x55'),
    (z80.XOR(0x55), b'\xee\x55'),
    (z80.OR(0x55), b'\xf6\x55'),
    (z80.CP(0x55), b'\xfe\x55'),
    (z80.CP(-1), b'\xfe\xff'),
    (z80.SUB(_symbol('mask', 0x0f)), b'\xd6\x0f'),
    (z80.RLC(z80.B), b'\xcb\x00'),
    (z80.RLC(z80.A), b'\xcb\x07'),
    (z80.RLC(z80.At(z80.HL)), b'\xcb\x06'),
    (z80.RRC(z80.B), b'\xcb\x08'),
    (z80.RL(z80.C), b'\xcb\x11'),
    (z80.RR(z80.D), b'\xcb\x1a'),
    (z80.SLA(z80.E), b'\xcb\x23'),
    (z80.SRA(z80.H), b'\xcb\x2c'),
    (z80.SLL(z80.L), b'\xcb\x35'),
    (z80.SRL(z80.At(z80.HL)), b'\xcb\x3e'),
    (z80.BIT(0, z80.B), b'\xcb\x40'),
    (z80.BIT(7, z80.A), b'\xcb\x7f'),
    (z80.BIT(3, z80.At(z80.HL)), b'\xcb\x5e'),
    (z80.RES(0, z80.B), b'\xcb\x80'),
    (z80.RES(6, z80.At(z80.HL)), b'\xcb\xb6'),
    (z80.SET(0, z80.B), b'\xcb\xc0'),
    (z80.SET(7, z80.A), b'\xcb\xff'),
    (z80.XNOP(0xed00), b'\xed\x00'),
    (z80.XNOP(0xed77), b'\xed\x77'),
    (z80.XNOP(0xed7f), b'\xed\x7f'),
    (z80.XNOP(0xeda4), b'\xed\xa4'),
    (z80.XNOP(0xedff), b'\xed\xff'),
)


@pytest.mark.parametrize('instr, image', _TESTS, ids=str)
def test_encode(instr: z80.Instr, image: bytes) -> None:
    assert instr.encode() == image


def test_no_such_form() -> None:
    with pytest.raises(z80.InstrError,
                       match='The target must be one of '
                             r'0x00, 0x08, \.\.\., 0x38.') as exc_info:
        z80.RST(0x29)

    assert str(exc_info.value.instr) == 'rst 0x29'

    with pytest.raises(z80.Error, match="Undefined symbol 'main'."):
        z80.RST(_symbol('main'))

    with pytest.raises(z80.InstrError,
                       match='The mode must be 0, 1 or 2.'):
        z80.IM(3)

    with pytest.raises(z80.InstrError,
                       match='The prefix byte must be 0xdd or 0xfd.'):
        z80.XPREFIX(0x12)

    with pytest.raises(z80.InvalidInstr) as exc_info:
        z80.EX(z80.HL, z80.DE)

    assert str(exc_info.value.instr) == 'ex hl, de'

    with pytest.raises(z80.InvalidInstr):
        z80.JP(z80.At(z80.BC))

    with pytest.raises(z80.InvalidInstr):
        z80.JP(z80.HL)

    # (ix + 0) is (ix); a real displacement makes no jp form.
    with pytest.raises(z80.InvalidInstr):
        z80.JP(z80.At(z80.IX, 5))

    with pytest.raises(z80.InvalidInstr):
        z80.RET(z80.HL)

    with pytest.raises(z80.InvalidInstr):
        z80.IN(z80.B, z80.At(0x12))

    with pytest.raises(z80.InvalidInstr):
        z80.IN(z80.At(z80.B))

    with pytest.raises(z80.InvalidInstr):
        z80.OUT(z80.At(z80.C), 1)

    with pytest.raises(z80.InvalidInstr):
        z80.OUT(z80.At(0x12), z80.B)

    with pytest.raises(z80.InvalidInstr):
        z80.LD(z80.IReg, z80.B)

    with pytest.raises(z80.InvalidInstr):
        z80.LD(z80.HL, z80.DE)

    with pytest.raises(z80.InvalidInstr):
        z80.LD(z80.B, z80.HL)

    with pytest.raises(z80.InvalidInstr):
        z80.LD(z80.HL, z80.B)

    # The prefix redirects both h/l slots at once.
    with pytest.raises(z80.InvalidInstr):
        z80.LD(z80.IXH, z80.L)

    with pytest.raises(z80.InvalidInstr):
        z80.LD(z80.IXH, z80.IYL)

    # The (hl), (hl) slot is halt.
    with pytest.raises(z80.InvalidInstr):
        z80.LD(z80.At(z80.HL), z80.At(z80.HL))

    # ED 44 is the true neg, not a duplicate.
    with pytest.raises(z80.InvalidInstr):
        z80.XNEG(0xed44)

    with pytest.raises(z80.InvalidInstr):
        z80.XNEG(0xed4d)

    # ED 45 is the true retn and ED 4D is reti.
    with pytest.raises(z80.InvalidInstr):
        z80.XRETN(0xed45)

    with pytest.raises(z80.InvalidInstr):
        z80.XRETN(0xed4d)

    # ED 63 pairs with the store shape only, and ED 6B with the
    # load.
    with pytest.raises(z80.InvalidInstr):
        z80.XLD(0xed63, z80.HL, z80.At(0x1234))

    with pytest.raises(z80.InvalidInstr):
        z80.XLD(0xed64, z80.At(0x1234), z80.HL)

    # ED 46 is a true im encoding, and ED 4E means mode 0.
    with pytest.raises(z80.InvalidInstr):
        z80.XIM(0xed46, 0)

    with pytest.raises(z80.InvalidInstr):
        z80.XIM(0xed4e, 1)

    with pytest.raises(z80.InvalidInstr):
        z80.PUSH(z80.SP)

    with pytest.raises(z80.InvalidInstr):
        z80.POP(z80.SP)

    with pytest.raises(z80.InvalidInstr):
        z80.INC(z80.AF)

    with pytest.raises(z80.InvalidInstr):
        z80.INC(z80.At(z80.BC))

    with pytest.raises(z80.InvalidInstr):
        z80.DEC(z80.AF)

    with pytest.raises(z80.InvalidInstr):
        z80.SUB(z80.BC)

    with pytest.raises(z80.InvalidInstr):
        z80.ADD(z80.B, z80.C)

    with pytest.raises(z80.InvalidInstr):
        z80.ADD(z80.HL, z80.IX)

    with pytest.raises(z80.InvalidInstr):
        z80.ADC(z80.IX, z80.BC)

    # No rotates of the index register halves exist.
    with pytest.raises(z80.InvalidInstr):
        z80.RLC(z80.IXH)

    with pytest.raises(z80.InstrError,
                       match='The bit number must be 0 through 7.'):
        z80.BIT(8, z80.B)

    with pytest.raises(z80.Error, match="'c' is not a value."):
        z80.BIT(z80.C, z80.B)

    with pytest.raises(z80.InvalidInstr):
        z80.BIT(0, z80.IXH)

    # ED 44 is neg and ED A0 is ldi: assigned, so not xnops.
    with pytest.raises(z80.InvalidInstr):
        z80.XNOP(0xed44)

    with pytest.raises(z80.InvalidInstr):
        z80.XNOP(0xeda0)


def test_immediates() -> None:
    # Immediates evaluate at encoding time, so forward references
    # construct first and bind later.
    s = _symbol('mask')
    instr = z80.SUB(s)
    with pytest.raises(z80.Error, match="Undefined symbol 'mask'."):
        instr.encode()

    s.value = 0x0f
    assert instr.encode() == b'\xd6\x0f'

    with pytest.raises(z80.InstrError,
                       match='0x100 does not fit a byte.'):
        z80.SUB(0x100).encode()

    with pytest.raises(z80.InstrError,
                       match='0x10000 does not fit a word.'):
        z80.LD(z80.BC, 0x10000).encode()


def test_relative() -> None:
    assert z80.JR(0x105).encode(0x100) == b'\x18\x03'
    assert z80.JR(z80.NZ, 0x105).encode(0x100) == b'\x20\x03'
    assert z80.JR(z80.Z, 0x105).encode(0x100) == b'\x28\x03'
    assert z80.JR(z80.NC, 0x105).encode(0x100) == b'\x30\x03'
    assert z80.JR(z80.CF, 0x100).encode(0x100) == b'\x38\xfe'
    assert z80.DJNZ(0x100).encode(0x100) == b'\x10\xfe'

    with pytest.raises(z80.InstrError,
                       match='The instruction address is unknown.'):
        z80.JR(0x105).encode()

    with pytest.raises(z80.InstrError,
                       match='The target 0x1000 is out of range.'):
        z80.JR(0x1000).encode(0x100)

    with pytest.raises(z80.InstrError,
                       match='The displacement 0x100 is out of range.'):
        z80.INC(z80.At(z80.IX, 0x100)).encode()

    # No jr forms for the po/pe/p/m conditions.
    with pytest.raises(z80.InvalidInstr):
        z80.JR(z80.M, 0x105)


def _check_identity(builder: z80.Z80InstrBuilder, image: bytes) -> None:
    instr, size = builder.build_instr(0x100, image)
    encoding = instr.encode(0x100)
    assert encoding == image[:size], (image.hex(), str(instr))

    # The size property counts the encoding fields on its own, so
    # check it against the actual encoding.
    assert instr.size == len(encoding), (image.hex(), str(instr))


# Every decodable byte sequence encodes back to itself: the pure-
# Python encoder and the C++ core's decoder certify each other.
def test_encode_decode_identity() -> None:
    builder = z80.Z80InstrBuilder()
    filler = b'\x34\x12'
    for op in range(0x100):
        if op not in (0xcb, 0xdd, 0xed, 0xfd):
            _check_identity(builder, bytes((op,)) + filler)

        _check_identity(builder, b'\xcb' + bytes((op,)))
        _check_identity(builder, b'\xed' + bytes((op,)) + filler)

        for prefix in (0xdd, 0xfd):
            # An inert index prefix decodes lossily (#72): where
            # the prefixed and unprefixed sequences decode the
            # same, the identity cannot hold and the sequence is
            # skipped.
            image = bytes((prefix, op)) + filler
            plain, _ = builder.build_instr(0x100, image[1:])
            prefixed, _ = builder.build_instr(0x100, image)
            if str(prefixed) != str(plain):
                _check_identity(builder, image)

            _check_identity(builder, bytes((prefix, 0xcb, 0x05, op)))
